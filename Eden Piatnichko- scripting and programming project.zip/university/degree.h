#pragma once

enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };  //Enumurated data type for the degree programs containing the data type values of security, network, and software. 